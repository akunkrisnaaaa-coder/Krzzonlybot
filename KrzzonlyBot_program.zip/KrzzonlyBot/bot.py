import os, io, logging
from PIL import Image
from telegram import Update
from telegram.ext import Application, CommandHandler, MessageHandler, ContextTypes, filters

logging.basicConfig(level=logging.INFO)
logging.getLogger("httpx").setLevel(logging.WARNING)
TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")

MENU = (
    "🤖 *KrzzonlyBot — Menu*\\n\\n"
    "/start — Mulai bot\\n/menu — Tampilkan menu\\n"
    "/ping — Cek bot\\n/id — Lihat ID chat dan akun\\n"
    "/sticker — Balas foto dengan perintah ini untuk membuat stiker"
)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.effective_message.reply_text("Halo! 👋 Aku KrzzonlyBot. Ketik /menu.")

async def menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.effective_message.reply_text(MENU, parse_mode="Markdown")

async def ping(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.effective_message.reply_text("🏓 Pong! Bot aktif.")

async def show_id(update: Update, context: ContextTypes.DEFAULT_TYPE):
    u, c = update.effective_user, update.effective_chat
    await update.effective_message.reply_text(f"Chat ID: {c.id}\\nUser ID: {u.id if u else '-'}")

async def sticker(update: Update, context: ContextTypes.DEFAULT_TYPE):
    msg = update.effective_message
    photos = msg.reply_to_message.photo if msg.reply_to_message else None
    if not photos:
        await msg.reply_text("Kirim foto, lalu balas foto itu dengan /sticker.")
        return
    try:
        tgfile = await context.bot.get_file(photos[-1].file_id)
        raw = io.BytesIO()
        await tgfile.download_to_memory(out=raw)
        raw.seek(0)
        with Image.open(raw) as im:
            im = im.convert("RGBA")
            im.thumbnail((512, 512))
            out = io.BytesIO()
            out.name = "krzzonly.webp"
            im.save(out, format="WEBP", quality=88, method=6)
            out.seek(0)
            await msg.reply_sticker(sticker=out)
    except Exception:
        logging.exception("Gagal membuat stiker")
        await msg.reply_text("Gagal membuat stiker. Coba foto lain.")

def main():
    if not TOKEN:
        raise SystemExit("Atur environment variable TELEGRAM_BOT_TOKEN dengan token BARU dari @BotFather.")
    app = Application.builder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("menu", menu))
    app.add_handler(CommandHandler("ping", ping))
    app.add_handler(CommandHandler("id", show_id))
    app.add_handler(CommandHandler("sticker", sticker))
    app.add_handler(CommandHandler("help", menu))
    app.add_handler(MessageHandler(filters.COMMAND, menu))
    print("KrzzonlyBot berjalan. Tekan Ctrl+C untuk berhenti.")
    app.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == "__main__":
    main()

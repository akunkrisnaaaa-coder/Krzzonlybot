KRZZONLYBOT — PANDUAN

FITUR
/start, /menu, /ping, /id, /sticker

KEAMANAN
Token bot kamu terlihat di screenshot sebelumnya. Buka @BotFather, kirim /revoke,
pilih bot, lalu gunakan token baru. Jangan kirim atau unggah token baru ke siapa pun.

FILE INI BELUM BERJALAN OTOMATIS.
Program perlu dijalankan di komputer atau hosting/server yang aktif.

MENJALANKAN DI KOMPUTER (Python 3.10+)
1. Ekstrak ZIP.
2. Buka terminal pada folder KrzzonlyBot.
3. Jalankan: pip install -r requirements.txt
4. Atur environment variable TELEGRAM_BOT_TOKEN dengan token BARU dari BotFather.
5. Jalankan: python bot.py

STIKER
Kirim foto ke bot, lalu balas foto tersebut dengan /sticker.
Untuk online 24 jam, program harus dijalankan di hosting/server yang tetap aktif.
Ketersediaan hosting gratis dan langkah pemasangannya dapat berubah.
